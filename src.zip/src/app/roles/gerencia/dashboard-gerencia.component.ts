import { Component } from '@angular/core';

@Component({
    selector: 'app-dashboard-gerencia',
    standalone: false,
    templateUrl: './dashboard-gerencia.component.html',
    styleUrls: ['./dashboard-gerencia.component.scss']
})
export class DashboardGerenciaComponent { }
