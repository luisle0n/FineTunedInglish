import { Component } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-dashboard-talento-humano',
  standalone: false,
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent {
  userMenuOpen = false;
  tituloSeccion = 'Inicio';

  constructor(private router: Router) {
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => this.actualizarTitulo());
  }

  actualizarTitulo() {
    const url = this.router.url;

    if (url.includes('inicio')) this.tituloSeccion = 'Inicio';
    else if (url.includes('docente')) this.tituloSeccion = 'Docentes';
    else if (url.includes('criterios')) this.tituloSeccion = 'Criterios';
    else if (url.includes('horarios')) this.tituloSeccion = 'Horarios';
    else this.tituloSeccion = 'Carga Horaria';
  }

  toggleUserMenu() {
    this.userMenuOpen = !this.userMenuOpen;
  }

  cerrarMenu() {
    setTimeout(() => this.userMenuOpen = false, 150);
  }

  verPerfil() {
    alert('Abrir vista de perfil');
    this.userMenuOpen = false;
  }

  cerrarSesion() {
    this.router.navigate(['/login']);
  }
}
