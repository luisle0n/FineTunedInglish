import { Component } from '@angular/core';

@Component({
  selector: 'app-docentes',
  standalone: false,
  templateUrl: './horario-coordinador.component.html',
  styleUrls: ['./horario-coordinador.component.scss']
})
export class HorarioCoordinadorComponent  { }
